from .memory import HashingMemory
